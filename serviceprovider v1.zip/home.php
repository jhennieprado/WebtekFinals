<?php
	session_start();
?>

<!DOCTYPE html>
<html>
	<head><title>Home</title></head>
	<body>
		<h1>Home<h1>

		<?php

			if(isset($_SESSION['message'])) {
				echo $_SESSION['message'];
				unset($_SESSION['message']);
			}

		?>

		<div>
			<h4>Welcome <?php echo $_SESSION['username']; ?></h4>
		</div>
		<div><a href="logout.php"> Logout </a></div>
	</body>
</html>

