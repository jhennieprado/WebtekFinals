/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Beans;

/**
 *
 * @author Vash
 */
public class ServiceProvider {
    private int spId;
    private String firstName;
    private String lastName;
    private String email;
    private int contactNo;
    private float totalRating;
    private String userName;
    private String password;
    private String status;
    private Object profpic;
    
    public ServiceProvider(){
        this.spId = 1;
        this.firstName = "awef";
        this.lastName = "awef";
        this.email = "awef";
        this.contactNo = 123;
        this.totalRating = (float) 5.0123;
        this.userName ="awef";
        this.password ="awef";
        this.status = "awef";
        this.profpic = null;
    }

    public ServiceProvider(int spId, String firstName, String lastName, String email, int contactNo, float totalRating, String userName, String password, String status) {
        this.spId = spId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.contactNo = contactNo;
        this.totalRating = totalRating;
        this.userName = userName;
        this.password = password;
        this.status = status;
        this.profpic = null;
    }
    
    
    public ServiceProvider(int spId, String firstName, String lastName, String email, int contactNo, float totalRating, String userName, String password, String status, Object profpic) {
        this.spId = spId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.contactNo = contactNo;
        this.totalRating = totalRating;
        this.userName = userName;
        this.password = password;
        this.status = status;
        this.profpic = profpic;
    }

    public void setSpId(int spId) {
        this.spId = spId;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setContactNo(int contactNo) {
        this.contactNo = contactNo;
    }

    public void setTotalRating(float totalRating) {
        this.totalRating = totalRating;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public void setProfpic(Object profpic) {
        this.profpic = profpic;
    }

    
    
    public int getSpId() {
        return spId;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getEmail() {
        return email;
    }

    public int getContactNo() {
        return contactNo;
    }

    public float getTotalRating() {
        return totalRating;
    }

    public String getUserName() {
        return userName;
    }

    public String getPassword() {
        return password;
    }

    public String getStatus() {
        return status;
    }

    public Object getProfpic() {
        return profpic;
    }

    
    
           
}
