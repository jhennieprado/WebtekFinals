/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Servlets;

import Beans.ServiceProvider;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Vash
 */
@WebServlet(name = "ConvertResultSetServlet", urlPatterns = {"/ConvertResultSetServlet"})
public class ConvertResultSetServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
       
        /**
         * This is repeated code. You better refactor this as a method 
         * since you can reuse this to full effect
        */
        if("spY".equals((String) request.getAttribute("bean"))){
            ResultSet validSp = (ResultSet) request.getAttribute("result");
            ArrayList<ServiceProvider> list = new ArrayList<> ();

            try{
                while(validSp.next()){
                    int spId = validSp.getInt(1) ;
                    String first_name  = validSp.getString(2);
                    String last_name = validSp.getString(3); 
                    String email = validSp.getString(4);
                    int contactNo = validSp.getInt(5);
                    float totalRating = validSp.getFloat(6);
                    String userName = validSp.getString(7);
                    String passWord = validSp.getString(8);
                    String accepted = validSp.getString(9);

                    ServiceProvider sp = new ServiceProvider(spId,first_name,last_name,
                            email,contactNo,totalRating,userName,passWord,accepted);
                    list.add(sp);
                }
            } catch (SQLException ex) {
                Logger.getLogger(ConvertResultSetServlet.class.getName()).log(Level.SEVERE, null, ex);
                ex.printStackTrace();
            }

            request.setAttribute("ValidSpList",list);
            System.out.println(list.size());
            RequestDispatcher dispatcher = request.getRequestDispatcher("DeleteSp.jsp");
            dispatcher.forward(request, response);
        }
        
        if("spN".equals((String) request.getAttribute("bean"))){
            ResultSet pendingSp = (ResultSet) request.getAttribute("result");
            ArrayList<ServiceProvider> list = new ArrayList<> ();
                    
            try{
                while(pendingSp.next()){
                    int spId = pendingSp.getInt(1) ;
                    String first_name  = pendingSp.getString(2);
                    String last_name = pendingSp.getString(3); 
                    String email = pendingSp.getString(4);
                    int contactNo = pendingSp.getInt(5);
                    float totalRating = pendingSp.getFloat(6);
                    String userName = pendingSp.getString(7);
                    String passWord = pendingSp.getString(8);
                    String accepted = pendingSp.getString(9);

                    ServiceProvider sp = new ServiceProvider(spId,first_name,last_name,
                            email,contactNo,totalRating,userName,passWord,accepted);
                    list.add(sp);
                }
            }catch(SQLException ex){
                Logger.getLogger(ConvertResultSetServlet.class.getName()).log(Level.SEVERE, null, ex);
                ex.printStackTrace();
            }
            request.setAttribute("PendingSp",list);
            System.out.println(list.size());
            RequestDispatcher dispatcher = request.getRequestDispatcher("ApproveSp.jsp");
            dispatcher.forward(request, response);
        }
        
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
